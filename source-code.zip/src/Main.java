import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.*;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.util.Base64;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) { }
            new CRSFrame().setVisible(true);
        });
    }
}

/** Main window. The buttons shown depend on the logged-in user's role. */
class CRSFrame extends JFrame {
    private static final long serialVersionUID = 1L;
    private DBConnection.User user;
    private final JTabbedPane tabs = new JTabbedPane();

    public CRSFrame() {
        showLogin();
    }

    private void showLogin() {
        setTitle("Course Registration System - Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(390, 230);
        setLocationRelativeTo(null);
        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(28, 28, 28, 28));
        JTextField username = new JTextField();
        JPasswordField password = new JPasswordField();
        JButton login = new JButton("Login");
        panel.add(new JLabel("Username")); panel.add(username);
        panel.add(new JLabel("Password")); panel.add(password);
        panel.add(new JLabel()); panel.add(login);
        login.addActionListener(e -> doLogin(username.getText().trim(), new String(password.getPassword())));
        password.addActionListener(e -> doLogin(username.getText().trim(), new String(password.getPassword())));
        setContentPane(panel);
    }

    private void doLogin(String name, String password) {
        try {
            user = DBConnection.login(name, password);
            if (user == null) {
                JOptionPane.showMessageDialog(this, "Incorrect username or password.");
                return;
            }
            showDashboard();
        } catch (Exception e) { showError(e); }
    }

    private void showDashboard() {
        setTitle("Course Registration System - " + user.name + " (" + user.role + ")");
        setSize(1000, 620);
        JPanel top = new JPanel(new BorderLayout());
        top.setBorder(BorderFactory.createEmptyBorder(10, 14, 10, 14));
        top.add(new JLabel("Welcome, " + user.name));
        JButton logout = new JButton("Logout");
        logout.addActionListener(e -> { user = null; tabs.removeAll(); showLogin(); });
        top.add(logout, BorderLayout.EAST);

        tabs.removeAll();
        tabs.addTab("Courses", coursesPanel());
        if (is("ADMIN")) tabs.addTab("Students", studentsPanel());
        if (is("ADMIN") || is("STUDENT")) tabs.addTab("Registration", registrationPanel());
        tabs.addTab("Academic Records", recordsPanel());
        if (is("ADMIN") || is("FACULTY")) tabs.addTab("Reports", reportsPanel());

        JPanel main = new JPanel(new BorderLayout());
        main.add(top, BorderLayout.NORTH);
        main.add(tabs, BorderLayout.CENTER);
        setContentPane(main);
        setLocationRelativeTo(null);
    }

    private JPanel coursesPanel() {
        JTable table = new JTable();
        JPanel panel = tablePanel(table);
        JPanel buttons = new JPanel();
        JButton refresh = new JButton("Refresh");
        refresh.addActionListener(e -> load(table, courseSql()));
        buttons.add(refresh);
        if (is("ADMIN") || is("FACULTY")) {
            JButton add = new JButton("Add Course");
            JButton edit = new JButton("Edit Course");
            buttons.add(add); buttons.add(edit);
            add.addActionListener(e -> courseForm(null));
            edit.addActionListener(e -> {
                int row = table.getSelectedRow();
                if (row >= 0) courseForm((Integer) table.getValueAt(row, 0));
                else message("Select a course first.");
            });
        }
        if (is("ADMIN")) {
            JButton delete = new JButton("Delete Course"); buttons.add(delete);
            delete.addActionListener(e -> {
                int row = table.getSelectedRow();
                if (row >= 0 && confirm("Delete selected course?")) run(() -> {
                    DBConnection.execute("DELETE FROM courses WHERE id=?", table.getValueAt(row, 0));
                    load(table, courseSql());
                });
            });
        }
        panel.add(buttons, BorderLayout.SOUTH);
        load(table, courseSql());
        return panel;
    }

    private String courseSql() {
        return "SELECT c.id AS ID,c.course_code AS Code,c.title AS Title,c.credit_hours AS Credits,"
                + "c.department AS Department,c.prerequisite_course_id AS Prerequisite,c.capacity AS Capacity,"
                + "COUNT(e.id) AS Enrolled FROM courses c LEFT JOIN enrollments e ON e.course_id=c.id "
                + "AND e.status='ENROLLED' GROUP BY c.id ORDER BY c.course_code";
    }

    private void courseForm(Integer id) {
        try {
            Object[] old = null;
            if (id != null) {
                DefaultTableModel model = DBConnection.getTable(
                        "SELECT course_code,title,credit_hours,department,prerequisite_course_id,capacity FROM courses WHERE id=?", id);
                if (model.getRowCount() > 0) {
                    old = new Object[6];
                    for (int i = 0; i < 6; i++) old[i] = model.getValueAt(0, i);
                }
            }
            String[] values = form("Course Details",
                    new String[]{"Course Code", "Title", "Credit Hours", "Department", "Prerequisite Course ID (optional)", "Maximum Capacity"}, old);
            if (values == null) return;
            Integer prerequisite = values[4].isBlank() ? null : Integer.valueOf(values[4]);
            String sql = id == null
                    ? "INSERT INTO courses(course_code,title,credit_hours,department,prerequisite_course_id,capacity) VALUES(?,?,?,?,?,?)"
                    : "UPDATE courses SET course_code=?,title=?,credit_hours=?,department=?,prerequisite_course_id=?,capacity=? WHERE id=?";
            if (id == null) DBConnection.execute(sql, values[0], values[1], Integer.parseInt(values[2]), values[3], prerequisite, Integer.parseInt(values[5]));
            else DBConnection.execute(sql, values[0], values[1], Integer.parseInt(values[2]), values[3], prerequisite, Integer.parseInt(values[5]), id);
            refreshTab();
        } catch (Exception e) { showError(e); }
    }

    private JPanel studentsPanel() {
        JTable table = new JTable();
        JPanel panel = tablePanel(table);
        JPanel buttons = new JPanel();
        JButton add = new JButton("Add Student"), edit = new JButton("Edit Student"), delete = new JButton("Delete Student"), refresh = new JButton("Refresh");
        buttons.add(add); buttons.add(edit); buttons.add(delete); buttons.add(refresh);
        add.addActionListener(e -> studentForm(null));
        edit.addActionListener(e -> { int row=table.getSelectedRow(); if(row>=0) studentForm((Integer)table.getValueAt(row,0)); else message("Select a student first."); });
        delete.addActionListener(e -> { int row=table.getSelectedRow(); if(row>=0 && confirm("Delete selected student?")) run(() -> { DBConnection.execute("DELETE FROM students WHERE id=?",table.getValueAt(row,0)); load(table,studentSql()); }); });
        refresh.addActionListener(e -> load(table,studentSql()));
        panel.add(buttons,BorderLayout.SOUTH);
        load(table,studentSql());
        return panel;
    }

    private String studentSql() {
        return "SELECT id AS ID,student_no AS Student_ID,full_name AS Name,dob AS Date_of_Birth,"
                + "program AS Program,study_year AS Year,email AS Email,phone AS Phone FROM students ORDER BY student_no";
    }

    private void studentForm(Integer id) {
        try {
            Object[] old = null;
            if (id != null) {
                DefaultTableModel m=DBConnection.getTable("SELECT student_no,full_name,dob,program,study_year,email,phone FROM students WHERE id=?",id);
                if(m.getRowCount()>0){old=new Object[7];for(int i=0;i<7;i++)old[i]=m.getValueAt(0,i);}
            }
            String[] v=form("Student Details",new String[]{"Student ID","Name","Date of Birth (YYYY-MM-DD)","Program of Study","Study Year","Email","Contact Number"},old);
            if(v==null)return;
            String sql=id==null?"INSERT INTO students(student_no,full_name,dob,program,study_year,email,phone) VALUES(?,?,?,?,?,?,?)":
                    "UPDATE students SET student_no=?,full_name=?,dob=?,program=?,study_year=?,email=?,phone=? WHERE id=?";
            if(id==null)DBConnection.execute(sql,v[0],v[1],v[2],v[3],Integer.parseInt(v[4]),v[5],v[6]);
            else DBConnection.execute(sql,v[0],v[1],v[2],v[3],Integer.parseInt(v[4]),v[5],v[6],id);
            refreshTab();
        }catch(Exception e){showError(e);}
    }

    private JPanel registrationPanel() {
        JPanel panel = new JPanel(new BorderLayout(8,8));
        JTable table = new JTable();
        JPanel form = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField student = new JTextField(user.studentId == null ? "" : user.studentId.toString(),7);
        JTextField course = new JTextField(6);
        JTextField year = new JTextField("2026",6);
        JComboBox<String> semester = new JComboBox<>(new String[]{"Semester 1","Semester 2"});
        if(is("STUDENT"))student.setEditable(false);
        JButton register = new JButton("Register Course");
        form.add(new JLabel("Student ID"));form.add(student);form.add(new JLabel("Course ID"));form.add(course);
        form.add(semester);form.add(new JLabel("Year"));form.add(year);form.add(register);
        register.addActionListener(e -> run(() -> {
            int studentId = Integer.parseInt(student.getText().trim());
            if(is("STUDENT") && !user.studentId.equals(studentId))throw new SecurityException("You can only register your own student account.");
            DBConnection.registerCourse(studentId,Integer.parseInt(course.getText().trim()),(String)semester.getSelectedItem(),Integer.parseInt(year.getText().trim()));
            message("Course registration completed.");
            load(table, enrollmentSql());
            tabs.setComponentAt(0, coursesPanel());
        }));
        panel.add(form,BorderLayout.NORTH);
        panel.add(new JScrollPane(table),BorderLayout.CENTER);
        JButton drop = new JButton("Drop Selected Course");
        drop.addActionListener(e -> {int row=table.getSelectedRow();if(row>=0)run(()->{DBConnection.dropCourse((Integer)table.getValueAt(row,0),is("STUDENT")?user.studentId:null);load(table,enrollmentSql());});else message("Select a registration first.");});
        panel.add(drop,BorderLayout.SOUTH);
        load(table,enrollmentSql());
        return panel;
    }

    private JPanel recordsPanel() {
        JTable table=new JTable(); JPanel panel=tablePanel(table);
        JButton refresh=new JButton("Refresh");refresh.addActionListener(e->load(table,enrollmentSql()));
        JPanel buttons=new JPanel();buttons.add(refresh);
        if(is("ADMIN")||is("FACULTY")){
            JButton grade=new JButton("Enter Grade");buttons.add(grade);
            grade.addActionListener(e->{int row=table.getSelectedRow();if(row<0){message("Select an enrolment first.");return;}
                String value=JOptionPane.showInputDialog(this,"Enter grade (A, A-, B+, B, B-, C+, C, D or F):");
                if(value!=null)run(()->{String g=value.trim().toUpperCase();if(!java.util.Arrays.asList("A","A-","B+","B","B-","C+","C","D","F").contains(g))throw new IllegalArgumentException("Enter a valid grade.");DBConnection.execute("UPDATE enrollments SET grade=?,status='COMPLETED' WHERE id=?",g,table.getValueAt(row,0));load(table,enrollmentSql());});
            });
        }
        panel.add(buttons,BorderLayout.SOUTH);load(table,enrollmentSql());return panel;
    }

    private String enrollmentSql() {
        String sql="SELECT e.id AS Enrollment_ID,s.student_no AS Student_ID,s.full_name AS Student,c.course_code AS Course,"
                +"c.title AS Course_Title,e.semester AS Semester,e.academic_year AS Year,e.status AS Status,e.grade AS Grade "
                +"FROM enrollments e JOIN students s ON s.id=e.student_id JOIN courses c ON c.id=e.course_id";
        if(is("STUDENT"))sql+=" WHERE s.id="+user.studentId;
        return sql+" ORDER BY e.academic_year DESC,e.semester,s.student_no";
    }

    private JPanel reportsPanel() {
        JPanel panel=tablePanel(new JTable());
        JTable table=(JTable)((JScrollPane)panel.getComponent(0)).getViewport().getView();
        JPanel buttons=new JPanel();
        JComboBox<String> report=new JComboBox<>(new String[]{"Course Enrolments and Vacancies","Student Academic Progress","Student Schedules"});
        JButton view=new JButton("View Report");buttons.add(report);buttons.add(view);panel.add(buttons,BorderLayout.SOUTH);
        view.addActionListener(e->{String selected=(String)report.getSelectedItem();
            if(selected.startsWith("Course"))load(table,"SELECT c.course_code AS Course,c.title AS Title,c.capacity AS Capacity,COUNT(e.id) AS Enrolled,c.capacity-COUNT(e.id) AS Vacancies FROM courses c LEFT JOIN enrollments e ON e.course_id=c.id AND e.status='ENROLLED' GROUP BY c.id ORDER BY c.course_code");
            else if(selected.startsWith("Student Academic"))load(table,"SELECT s.student_no AS Student_ID,s.full_name AS Student,c.course_code AS Course,c.title AS Title,e.semester AS Semester,e.academic_year AS Year,e.status AS Status,e.grade AS Grade FROM enrollments e JOIN students s ON s.id=e.student_id JOIN courses c ON c.id=e.course_id ORDER BY s.student_no,e.academic_year");
            else load(table,"SELECT s.student_no AS Student_ID,s.full_name AS Student,c.course_code AS Course,c.title AS Title,e.semester AS Semester,e.academic_year AS Year FROM enrollments e JOIN students s ON s.id=e.student_id JOIN courses c ON c.id=e.course_id WHERE e.status='ENROLLED' ORDER BY s.student_no,c.course_code");
        });
        view.doClick();return panel;
    }

    private JPanel tablePanel(JTable table){JPanel p=new JPanel(new BorderLayout());p.add(new JScrollPane(table),BorderLayout.CENTER);return p;}
    private void load(JTable table,String sql){try{table.setModel(DBConnection.getTable(sql));}catch(Exception e){showError(e);}}
    private String[] form(String title,String[] labels,Object[] old){
        JPanel panel=new JPanel(new GridLayout(labels.length,2,8,8));JTextField[] fields=new JTextField[labels.length];
        for(int i=0;i<labels.length;i++){panel.add(new JLabel(labels[i]));fields[i]=new JTextField(old==null||old[i]==null?"":old[i].toString());panel.add(fields[i]);}
        int result=JOptionPane.showConfirmDialog(this,panel,title,JOptionPane.OK_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE);
        if(result!=JOptionPane.OK_OPTION)return null;String[] values=new String[fields.length];for(int i=0;i<fields.length;i++)values[i]=fields[i].getText().trim();return values;
    }
    private boolean is(String role){return user!=null&&role.equals(user.role);}
    private boolean confirm(String text){return JOptionPane.showConfirmDialog(this,text,"Confirm",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION;}
    private void message(String text){JOptionPane.showMessageDialog(this,text);}
    private void showError(Exception e){JOptionPane.showMessageDialog(this,e.getMessage()==null?"An error occurred.":e.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);}
    private interface Action{void run()throws Exception;}
    private void run(Action action){try{action.run();}catch(Exception e){showError(e);}}
    private void refreshTab(){int i=tabs.getSelectedIndex();String name=tabs.getTitleAt(i);tabs.setComponentAt(i,switch(name){case "Courses"->coursesPanel();case "Students"->studentsPanel();case "Registration"->registrationPanel();case "Academic Records"->recordsPanel();case "Reports"->reportsPanel();default->new JPanel();});}
}

/** Database and SQL operations for the Course Registration System. */
class DBConnection {
    private static final String URL = System.getenv().getOrDefault(
            "CRS_DB_URL", "jdbc:mysql://localhost:3306/crs_db?serverTimezone=UTC");
    private static final String USER = System.getenv().getOrDefault("CRS_DB_USER", "root");
    private static final String PASSWORD = System.getenv().getOrDefault("CRS_DB_PASSWORD", "");

    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // Demo passwords are stored as PBKDF2 hashes in the database.
    private static boolean checkPassword(String password, String stored) {
        try {
            String[] parts = stored.split(":");
            int rounds = Integer.parseInt(parts[0]);
            byte[] salt = Base64.getDecoder().decode(parts[1]);
            byte[] expected = Base64.getDecoder().decode(parts[2]);
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, rounds, expected.length * 8);
            byte[] actual = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec).getEncoded();
            return java.security.MessageDigest.isEqual(expected, actual);
        } catch (Exception e) {
            return false;
        }
    }

    public static User login(String username, String password) throws SQLException {
        String sql = "SELECT id, username, password_hash, full_name, role FROM users "
                + "WHERE username=? AND active=1";
        try (Connection con = connect(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next() || !checkPassword(password, rs.getString("password_hash"))) {
                    return null;
                }
                Integer studentId = null;
                if ("STUDENT".equals(rs.getString("role"))) {
                    try (PreparedStatement studentQuery = con.prepareStatement(
                            "SELECT id FROM students WHERE user_id=?")) {
                        studentQuery.setInt(1, rs.getInt("id"));
                        try (ResultSet student = studentQuery.executeQuery()) {
                            if (student.next()) studentId = student.getInt("id");
                        }
                    }
                }
                return new User(rs.getInt("id"), rs.getString("full_name"),
                        rs.getString("role"), studentId);
            }
        }
    }

    public static javax.swing.table.DefaultTableModel getTable(String sql, Object... values)
            throws SQLException {
        javax.swing.table.DefaultTableModel model = new javax.swing.table.DefaultTableModel();
        try (Connection con = connect(); PreparedStatement ps = con.prepareStatement(sql)) {
            for (int i = 0; i < values.length; i++) ps.setObject(i + 1, values[i]);
            try (ResultSet rs = ps.executeQuery()) {
                ResultSetMetaData meta = rs.getMetaData();
                for (int i = 1; i <= meta.getColumnCount(); i++) {
                    model.addColumn(meta.getColumnLabel(i));
                }
                while (rs.next()) {
                    Object[] row = new Object[meta.getColumnCount()];
                    for (int i = 1; i <= row.length; i++) row[i - 1] = rs.getObject(i);
                    model.addRow(row);
                }
            }
        }
        return model;
    }

    public static void execute(String sql, Object... values) throws SQLException {
        try (Connection con = connect(); PreparedStatement ps = con.prepareStatement(sql)) {
            for (int i = 0; i < values.length; i++) ps.setObject(i + 1, values[i]);
            ps.executeUpdate();
        }
    }

    public static void registerCourse(int studentId, int courseId, String semester, int year)
            throws SQLException {
        try (Connection con = connect()) {
            con.setAutoCommit(false);
            try {
                String dateSql = "SELECT COUNT(*) FROM semesters WHERE semester=? AND academic_year=? "
                        + "AND CURRENT_DATE BETWEEN registration_start AND registration_end";
                try (PreparedStatement ps = con.prepareStatement(dateSql)) {
                    ps.setString(1, semester);
                    ps.setInt(2, year);
                    try (ResultSet rs = ps.executeQuery()) {
                        rs.next();
                        if (rs.getInt(1) == 0) throw new SQLException("Registration is not open for this semester.");
                    }
                }

                int capacity;
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT capacity FROM courses WHERE id=? FOR UPDATE")) {
                    ps.setInt(1, courseId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) throw new SQLException("Course was not found.");
                        capacity = rs.getInt(1);
                    }
                }

                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT COUNT(*) FROM enrollments WHERE course_id=? AND semester=? "
                                + "AND academic_year=? AND status='ENROLLED'")) {
                    ps.setInt(1, courseId);
                    ps.setString(2, semester);
                    ps.setInt(3, year);
                    try (ResultSet rs = ps.executeQuery()) {
                        rs.next();
                        if (rs.getInt(1) >= capacity) throw new SQLException("This course is full.");
                    }
                }

                Object prerequisite = null;
                try (PreparedStatement ps = con.prepareStatement(
                        "SELECT prerequisite_course_id FROM courses WHERE id=?")) {
                    ps.setInt(1, courseId);
                    try (ResultSet rs = ps.executeQuery()) {
                        rs.next();
                        prerequisite = rs.getObject(1);
                    }
                }
                if (prerequisite != null) {
                    String check = "SELECT COUNT(*) FROM enrollments WHERE student_id=? AND course_id=? "
                            + "AND status='COMPLETED' AND grade IS NOT NULL AND grade NOT IN ('F','N/A')";
                    try (PreparedStatement ps = con.prepareStatement(check)) {
                        ps.setInt(1, studentId);
                        ps.setInt(2, ((Number) prerequisite).intValue());
                        try (ResultSet rs = ps.executeQuery()) {
                            rs.next();
                            if (rs.getInt(1) == 0) throw new SQLException("The prerequisite course has not been completed.");
                        }
                    }
                }

                String existing = "SELECT id,status FROM enrollments WHERE student_id=? AND course_id=? "
                        + "AND semester=? AND academic_year=? FOR UPDATE";
                boolean added = false;
                try (PreparedStatement ps = con.prepareStatement(existing)) {
                    ps.setInt(1, studentId); ps.setInt(2, courseId);
                    ps.setString(3, semester); ps.setInt(4, year);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            if (!"DROPPED".equals(rs.getString("status"))) {
                                throw new SQLException("This student is already registered for the course.");
                            }
                            try (PreparedStatement update = con.prepareStatement(
                                    "UPDATE enrollments SET status='ENROLLED', grade=NULL WHERE id=?")) {
                                update.setInt(1, rs.getInt("id"));
                                update.executeUpdate();
                                added = true;
                            }
                        }
                    }
                }
                if (!added) {
                    try (PreparedStatement ps = con.prepareStatement(
                            "INSERT INTO enrollments(student_id,course_id,semester,academic_year,status) "
                                    + "VALUES(?,?,?,?, 'ENROLLED')")) {
                        ps.setInt(1, studentId); ps.setInt(2, courseId);
                        ps.setString(3, semester); ps.setInt(4, year);
                        ps.executeUpdate();
                    }
                }
                con.commit();
            } catch (Exception e) {
                con.rollback();
                if (e instanceof SQLException) throw (SQLException) e;
                throw new SQLException(e);
            } finally {
                con.setAutoCommit(true);
            }
        }
    }

    public static void dropCourse(int enrollmentId, Integer studentId) throws SQLException {
        String sql = "UPDATE enrollments e JOIN semesters s ON s.semester=e.semester "
                + "AND s.academic_year=e.academic_year SET e.status='DROPPED' "
                + "WHERE e.id=? AND e.status='ENROLLED' "
                + "AND CURRENT_DATE BETWEEN s.registration_start AND s.registration_end";
        if (studentId != null) sql += " AND e.student_id=?";
        try (Connection con = connect(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, enrollmentId);
            if (studentId != null) ps.setInt(2, studentId);
            if (ps.executeUpdate() == 0) {
                throw new SQLException("Course could not be dropped. Check the selected record and registration dates.");
            }
        }
    }

    public static class User {
        public final int id;
        public final String name;
        public final String role;
        public final Integer studentId;
        public User(int id, String name, String role, Integer studentId) {
            this.id = id; this.name = name; this.role = role; this.studentId = studentId;
        }
    }
}
